import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.avro.AvroParquetReader;
import org.apache.parquet.avro.AvroParquetWriter;
import org.apache.parquet.hadoop.ParquetReader;
import org.apache.parquet.hadoop.ParquetWriter;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;

public class FastParquet {
	
	public ParquetReader<GenericRecord> reader;
	public char delimiter = ','; 
	public FastReader scanner;
	public FastWriter writer;
	public FastParquet() {
		try {
			System.setProperty("hadoop.home.dir", new java.io.File(".").getCanonicalPath() + "\\hadoop-3.0.0");
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public void parquetReader(String filePath) {
		try { reader = new AvroParquetReader<GenericRecord>(new Path((new File(filePath)).toString())); } 
		catch (IOException e) {}
	}
	
	public String nextLine() {
		try { GenericRecord nextRecord = reader.read(); return nextRecord.toString(); } catch (IOException e) {}
		return null;
	}
	
	public void parquetCloseReader() {
		try { reader.close(); }
		catch (IOException e) {}
	}
	public String createSchema(String[] fields) {
		String schema = "{"
				+ "\"namespace\": \"org.myorg.myname\",\"type\": \"record\","
				+ "\"name\": \"patient\",\""
				+ "fields\": [ ";
		for(int i = 0; i < fields.length-1; i++) {
			schema += "{\"name\": \"" + fields[i].replace(" ", "") + "\", \"type\": [\"string\", \"null\"]}, ";
		}
		schema += "{\"name\": \"" + fields[fields.length-1].replace(" ", "") + "\", \"type\": [\"string\", \"null\"]} ]}";
		schema = schema.replace(".", "").replace("(", "").replace(")", "").replace("_", "");
		return schema;
	}
	
	public GenericData.Record createRecord(String line, String [] fields, Schema avroSchema){
		String line2 = line;
		String [] arr = scanner.csvLineToArray(line2, delimiter);
		GenericData.Record record = new GenericData.Record(avroSchema);
		for(int i = 0; i < fields.length; i++) {
			record.put(fields[i], arr[i]);
		}
		return record;
	}
	
	public void parquetWriteCSVToParquet(String inputFile, String outputFile, CompressionCodecName codec, int pageSize, long rowGroupSize) {
		FastReader cr = new FastReader(inputFile);
		String line = cr.nextLine();
		line = "Index" + line;
		
		String [] fields = scanner.csvLineToArray(line, delimiter);
		Schema avroSchema = (new Schema.Parser().setValidate(true)).parse(createSchema(fields));
		System.out.println(line);
		System.out.println(Arrays.toString(fields));
		double count = 0;
		long time = System.currentTimeMillis();
		try {
			try (@SuppressWarnings("deprecation")
			ParquetWriter<Object> writer = AvroParquetWriter.builder(new Path(outputFile))
			.withSchema(avroSchema)
			.withCompressionCodec(codec)
			.withConf(new Configuration())
			.withPageSize(pageSize)
			.withRowGroupSize(rowGroupSize)
			.build()) {
				line = cr.nextLine();
				while(line != null) {
					org.apache.avro.generic.GenericData.Record record = createRecord(line, fields, avroSchema);
					try {
						writer.write(record);
						count++;
						if(count % 10000 == 0) {
							System.out.println(count + "\t" + (System.currentTimeMillis() - time));
						}
					}
					catch(Exception e) {
						System.out.println("Error in the following record (line " + count + ") detected: " + record);
						e.printStackTrace();
					}
					line = cr.nextLine();
				}
				writer.close();
			}				   
		} catch (IOException e) { e.printStackTrace(System.out); }
		cr.close();
	}
}